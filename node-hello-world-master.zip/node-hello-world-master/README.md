# Node.js Hello World App

A simple app to test [Node.js](http://nodejs.org/) support.
